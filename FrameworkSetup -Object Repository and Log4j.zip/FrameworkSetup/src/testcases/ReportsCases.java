package testcases;

import org.testng.annotations.Test;

public class ReportsCases {
  @Test(groups= {"report"},priority=5)
  public void ValidateReport() {
	  System.out.println("Report - Testcase");
  }
}
