package testcases;

import org.testng.annotations.Test;

public class SignupCases {
  @Test
  public void NewAccount() {
	  
	  System.out.println("New Account");
	  
  }
}
