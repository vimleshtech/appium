package testcases;

import org.testng.annotations.Test;

import example.utils.ObjectReader;


import org.testng.annotations.BeforeTest;

import org.apache.log4j.Logger;

public class LoginWithSearch {
  
	//create the object of log4j 
	
	static Logger log  = Logger.getLogger(LoginWithSearch.class);
	
	
  @Test(priority=1,testName="Login",groups= {"login","search"})
  public void Step1() {
	
	  log.info("Step 1 is started");
	  
	  System.out.println("Step 1");
	  
	  System.out.println(ObjectReader.getElement("tag"));
	  
	  log.info("Step 1 is finished");
  }
  
  @Test(priority=2,testName="Search",groups= {"login","search"})
  public void Step2() {
	  log.info("Step 2 is started");
	  	  
	  System.out.println("Step 2");
	  
	  int n,d,o;
	  n =33;
	  d = 2;
	  try
	  {
		  o  =n/d;
	  }
	  catch (Exception e) {
		// TODO: handle exception
		  
		  log.fatal(e.toString());
	}
	  
	  
	  System.out.println(ObjectReader.getElement("email"));
	  System.out.println(ObjectReader.getElement("pwd"));
	  System.out.println(ObjectReader.getElement("btn_login"));
	  
	  log.info("Step 2 is finieshed");
  }
  
  @Test(priority=3,testName="Navigate",groups= {"search"})
  public void Step3() {
	  
	  log.info("Step 3 is started");
	  System.out.println("Step 3");
	  
	  log.info("Step 3 is finished");
  }
  
  @Test(priority=4,testName="Select",groups= {"search"})
  public void Step4() {
	  log.info("Step 4 is started");
	  
	  System.out.println("Step 4");
	  log.info("Step 4 is finished");
  }
    
  @BeforeTest
  public void beforeTest() {
	  
	  
  }

}
