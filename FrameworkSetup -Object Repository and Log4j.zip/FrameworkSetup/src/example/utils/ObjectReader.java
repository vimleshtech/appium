package example.utils;

import java.io.FileInputStream;
import java.util.Properties;

public class ObjectReader {

	
	public static String getElement(String key) {
		
		try
		{
			FileInputStream fs = new FileInputStream("C:\\Users\\vkumar15\\eclipse\\FrameworkSetup\\src\\example\\utils\\Objects.properties");
			
			Properties prop = new Properties();			
			prop.load(fs);
						
			return prop.getProperty(key);
		}
		catch (Exception e) 
		{
			System.out.println(e.toString());
		}		
		
		return null;
		
	}
	
	
}
